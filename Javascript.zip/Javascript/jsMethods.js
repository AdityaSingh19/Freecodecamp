//Js Methods
var obj = 
	{
		name: "Abc",
		age:23,
		isCool: false,
		friends: ["Bcd","Def"],
		add: function(x,y){
			return x + y;
		}
	}

//Namespace collision
function speak(){
	return "Woof!";
}
//speak(); will return Woof
function speak(){
	return "Meow!";
}
//speak(); will return Meow 
//but we have no longer access to our Woof this is called namespace collision
//To overcome this problem 
//create an empty object
var dogSpace = {};
//add the function to the object
dogSpace.speak=function(){
	return "Woof!";
}
var catSpace = {};
catSpace.speak = function(){
	return "Meow!";
}
//UnderScore.js
//This Keyword
var comments = {};
comments.data = ["Hi","Hello","Bye"];
function print(arr){
	arr.forEach(function(el){
		console.log[el];
	});
}
//Add print function to the object itself
comments.print = function(arr){
	arr.forEach(function(el){
		console.log[el];
	});
}
//But to make it to access data from comments we use this keyword
comments.print = function(){
	this.data.forEach(function(el){
		console.log[el];
	});
}
//here this refers to object comments
//now we can print easily just by
comments.print()