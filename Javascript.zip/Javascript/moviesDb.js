//Movies Database
var movies =[
	{
		title: "John Wick",
		rating: 5,
		hasWatched:true 
	},
	{
		title: "John Wick 2",
		rating: 6,
		hasWatched:true 
	},
	{
		title: "John Wick 3",
		rating: 7.5,
		hasWatched:false 
	}
]
function buildString(movie){
	var result = "You Have";
	if(movie.hasWatched){
		result += " watched";
	}else{
		result += " not seen";
	}
	result += " \"" + movie.title + "\" - ";
	result += movie.rating + " stars";
	return result;
}
movies.forEach(function(movie){
	console.log(buildString(movie));
})