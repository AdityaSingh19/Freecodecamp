var userName = prompt("What is your name?");
alert("Nice to meet you," + userName);
console.log("Also great to see you," + userName);