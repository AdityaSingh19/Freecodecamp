var a = [1,2,3,4];
function printReverse(a){
    for(i=a.length-1;i >=0; i--){
        console.log(a[i]);
    }
}

var b = [1,1,1,1];
function isUniform(b){
for(var i=1; i<b.length-1;i++){
	var c = b[0];
	if( c === b[i]){
		return true;
		}
	else{
		return false;
		}
	}
}
function sumArray(a){
	
	for(var i=1;i<a.length-1;i++){
		if(typeof(a[i])=== "number"){
		result=a[0];
		result +=a[i];
		return result;
	}
	else
	{
	console.log("Please enter numbers only");
	}
	} 
	
}

function sumArray(arr){
	var total = 0;
	arr.forEach(function(num){
		total +=num;

	});
	return total;
}
function max(arr){
	var max = arr[0];
	for(i=1;i<arr.length;i++){
		if(arr[i] > max){
			max = arr[i];
		}
	}
	return max;
}