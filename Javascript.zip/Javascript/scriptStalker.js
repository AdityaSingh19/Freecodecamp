var firstName = prompt("What is your first name?");
var lastName = prompt("What is your last name?");
var age = prompt("What is your age?");
console.log("hello " + firstName + "" + lastName );
console.log("your age is " + age);