var age = prompt("Enter Your age");
var days = age * 365.5;

alert("Your age is " + age + " years" + " your age is " + days + " days"  );