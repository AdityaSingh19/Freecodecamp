var secretNumber = 19;
var guess = Number(prompt("Guess a number !"));
if (guess === secretNumber) {
	alert("Your Guess is correct!!");
}
else if(guess < secretNumber){
	alert("Too Low!!");
}
else{
	alert("Too High!!");
}