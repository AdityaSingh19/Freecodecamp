var age = Number(prompt("Enter your age"));
if (age < 0) {
	console.log("Age entered is not correct");
}
else if (age == 21) {
	console.log("Happy 21st birthday");
}
else if ((age % 2) === 1) {
	console.log("your age is odd");
}
else if (age % Math.sqrt(age) === 0) {
  console.log("Perfect sqaure!");
}

else {
  console.log("Wow you are " + age + " years old!");
}