// var ans = prompt("Are we there yet");

// while(ans !== "yes"){
// 	var ans = prompt("Are we there yet");
// 	}

// alert("Yay,we finally made it");
//type 2

var ans = prompt("Are we there yet");

while(ans.indexOf("yes")){
	var ans = prompt("Are we there yet");
	}

alert("Yay,we finally made it");