var todos = [];
var input = prompt("What would you want to do?");
window.setTimeout(function() {
  // put all of your JS code from the lecture here


while(input !== "quit"){
	//handle input
	if(input === "list"){
		listTodo();
	} else if(input === "new"){
		newTodo();
	}else if (input === "delete") {
		deleteTodo();
	}
	//ask again for new Input
	input = prompt("What would you want to do?");
}
function listTodo(){
		console.log("*********");
		todos.forEach(function(todo,index){
			console.log(index + ": " +todo);
		});
		console.log("*********");
}
function newTodo(){
	//ask for new todo
		var newTodo = prompt("Enter your new Todo");
		//add new todos to array
		todos.push(newTodo);
		console.log(newTodo + "newly added Todo"); 
}
function deleteTodo(){
		var index = prompt("Enter index of todo to delte");
		todos.splice(index,1);
		console.log("Todo Removed");
}
console.log("Exiting application");
}, 500);
